CREATE TRIGGER [dbo].[ThreadDeleted]
ON [dbo].[Thread]
AFTER DELETE
AS
BEGIN

   DELETE FROM Rate WHERE threadId = (SELECT TOP 1 threadId FROM DELETED)
   DELETE FROM Image WHERE threadId = (SELECT TOP 1 threadId FROM DELETED)
   DELETE FROM Notification WHERE threadId = (SELECT TOP 1 threadId FROM DELETED)

END 

CREATE TRIGGER [dbo].[RateDeleted]
ON [dbo].[Rate]
AFTER DELETE
AS
BEGIN

   DELETE FROM Notification WHERE rateId = (SELECT TOP 1 rateId FROM DELETED)

END 


CREATE TRIGGER [dbo].[AccountDeleted]
ON [dbo].[Account]
AFTER DELETE
AS
BEGIN

   DELETE FROM Rate WHERE accountId = (SELECT TOP 1 accountId FROM DELETED)
   DELETE FROM Notification WHERE accountId = (SELECT TOP 1 accountId FROM DELETED)
   DELETE FROM Thread WHERE accountId = (SELECT TOP 1 accountId FROM DELETED)

END 