package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.been.NhanVat;


public class NhanVatDAO {

	DataAccess da=new DataAccess();
	Statement st=null;
	Connection cnn=null;
	ResultSet rs=null;

	/**
	 * Lấy top nhân vật dựa theo lượt xem
	 * @return
	 */
	public ArrayList<NhanVat> getTopNhanVat() {
		cnn=da.getConnect();
		String sql="select top 5 * from NHANVAT order by MANHANVAT DESC";
		ArrayList<NhanVat> list= new ArrayList<NhanVat>();
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			NhanVat nv;
			while(rs.next()){
				nv=new NhanVat();
				nv.setMaNhanVat(rs.getInt("MANHANVAT"));
				nv.setTenNhanVat(rs.getString("TENNHANVAT"));
				list.add(nv);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	public ArrayList<NhanVat> getNhanVatMoi() {
		cnn=da.getConnect();
		String sql="select top 5 * from NHANVAT order by MANHANVAT DESC";
		ArrayList<NhanVat> list= new ArrayList<NhanVat>();
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			NhanVat nv;
			while(rs.next()){
				nv=new NhanVat();
				nv.setMaNhanVat(rs.getInt("MANHANVAT"));
				nv.setTenNhanVat(rs.getString("TENNHANVAT"));
				nv.setHinhAnh(rs.getString("HINHANH"));
				String noiDung= rs.getString("NOIDUNG");
				if(noiDung.length()>100)
					nv.setNoiDung(rs.getString("NOIDUNG").substring(0, 100));
				else
					nv.setNoiDung(rs.getString("NOIDUNG"));
				list.add(nv);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

}
