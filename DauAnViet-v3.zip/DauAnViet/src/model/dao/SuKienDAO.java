package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.been.SuKien;

public class SuKienDAO {

	DataAccess da=new DataAccess();
	Statement st=null;
	Connection cnn=null;
	ResultSet rs=null;
	
	/**
	 * Lấy danh sách top 5 sự kiện được xem nhiều nhất
	 * @return
	 */
	public ArrayList<SuKien> getTopSuKien() {
		cnn=da.getConnect();
		String sql="select top 5 * from SUKIEN order by masukien DESC";
		ArrayList<SuKien> list= new ArrayList<SuKien>();
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			SuKien sk;
			while(rs.next()){
				sk=new SuKien();
				sk.setMaSuKien(rs.getInt("MASUKIEN"));
				sk.setTenSuKien(rs.getString("TENSUKIEN"));
				list.add(sk);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	
	/**
	 * Lấy top 3 sự kiện sắp diễn ra trong quá khứ dựa theo ngày và tháng hiện tại
	 * @param ngayDang
	 * @param ngay
	 * @param thang
	 * @return
	 */
	public ArrayList<SuKien> getTopSuKienSDR(String ngayDang, int ngay, int thang) {
		cnn=da.getConnect();
		String sql="select top 3 * from SUKIEN where day(NGAYBATDAU) <="+ngay+"";
		ArrayList<SuKien> list= new ArrayList<SuKien>();
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			SuKien sk;
			while(rs.next()){
				sk=new SuKien();
				sk.setMaSuKien(rs.getInt("MASUKIEN"));
				sk.setTenSuKien(rs.getString("TENSUKIEN"));
				list.add(sk);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}
	public static void main(String[] args) {
		SuKienDAO sk=new SuKienDAO();
		sk.getTopSuKienSDR("10", 1,1);
	}

	public ArrayList<SuKien> getTopSuKienMoi() {
		cnn=da.getConnect();
		String sql="select top 5 * from SUKIEN order by MASUKIEN DESC";
		ArrayList<SuKien> list= new ArrayList<SuKien>();
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			SuKien sk;
			while(rs.next()){
				sk=new SuKien();
				sk.setMaSuKien(rs.getInt("MASUKIEN"));
				sk.setTenSuKien(rs.getString("TENSUKIEN"));
				sk.setHinhAnh(rs.getString("HINHANH"));
				String noiDung= rs.getString("NOIDUNG");
				if(noiDung.length()>100)
					sk.setNoiDung(rs.getString("NOIDUNG").substring(0, 100));
				else
					sk.setNoiDung(rs.getString("NOIDUNG"));
				list.add(sk);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

}
