package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.been.GiaiDoan;
import model.been.NhanVatSuKien;
import model.been.NoiDung;
import model.been.ThoiKy;
import common.ProcessString;

public class GiaiDoanDAO {

	DataAccess da=new DataAccess();
	Statement st=null;
	Connection cnn=null;
	ResultSet rs=null;
	
	/**
	 * Lấy danh sách giai đoạn từ csdl theo mã thời kỳ
	 * @param id
	 * @return
	 */
	public ArrayList<GiaiDoan> getListGiaiDoan(int id) {
		cnn=da.getConnect();
		ArrayList<GiaiDoan> list = new ArrayList<GiaiDoan>();
		String sql="Select * from GIAIDOAN where MATHOIKI="+id+"";
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			GiaiDoan gd;
			while(rs.next()){
				gd=new GiaiDoan();
				gd.setMaGiaiDoan(rs.getInt("MAGIAIDOAN"));
				gd.setMaThoiKy(rs.getInt("MATHOIKI"));
				gd.setTenGiaiDoan(rs.getString("TENGIAIDOAN"));
				try{
					gd.setNgayBatDau(rs.getDate("NGAYBATDAU").toString().substring(0, 4));
				}catch (Exception e) {
					gd.setNgayBatDau("N/A");
				}
				try{
					gd.setNgayKetThuc(rs.getDate("NGAYKETTHUC").toString().substring(0, 4));
				}catch (Exception e) {
					gd.setNgayKetThuc("N/A");
				}

				String noiDung=rs.getString("NOIDUNG");
				String [] noiDungChia=noiDung.split(" ");
		
				if(noiDungChia.length>50)
					gd.setNoiDung(ProcessString.catChuoi(noiDungChia, 0, 50));
				else
					gd.setNoiDung(rs.getString("NOIDUNG"));
				gd.setBanDoGiaiDoan(rs.getString("BANDOGIAIDOAN"));
				gd.setHinhAnh(rs.getString("HINHANH"));
				list.add(gd);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	/**
	 * Lấy số lượng giai đoạn theo mã thời kỳ
	 * @param id
	 * @return
	 */
	public ArrayList<String> getPageGiaiDoan(int id) {
		cnn=da.getConnect();
		ArrayList<String> page =new ArrayList<String>();
		String sql="Select count(*) as page from GIAIDOAN where MATHOIKI="+id+"";
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);

			while(rs.next()){
				for(int i=1; i<=rs.getInt("page");i++){
					if (i==1)
						page.add("I");
					if (i==2)
						page.add("II");
					if (i==3)
						page.add("III");
					if (i==4)
						page.add("IV");
					if (i==5)
						page.add("V");
					if (i==6)
						page.add("VI");
					if (i==7)
						page.add("VII");
					if (i==8)
						page.add("VIII");
					if (i==9)
						page.add("IX");
					if (i==10)
						page.add("X");
				}

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return page;
	}

	/**
	 * Lấy số năm chia nhỏ theo 50 năm trong một giai đoạn
	 * @param id
	 * @param type
	 * @return
	 */
	public ArrayList<String> getNamChiaNho(int id, int type) {
		cnn=da.getConnect();
		ArrayList<String> listNam =new ArrayList<String>();
		String sql="Select Year(NGAYBATDAU) as ngaybd, Year(NGAYKETTHUC) as ngaykt from GIAIDOAN where MAGIAIDOAN="+id+"";
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				int ngaybd=rs.getInt("ngaybd");
				int ngaykt=rs.getInt("ngaykt");
				int sonam= ngaykt - ngaybd;
				if(sonam%50!=0)
					sonam=(sonam/50)+1;
				else
					sonam=(sonam/50);
				for(int i=1;i<=sonam;i++){
					if(i==1)
						listNam.add(Integer.toString(ngaybd));
					else
						if(i==sonam)
							listNam.add(Integer.toString(ngaykt));
						else{
							ngaybd=ngaybd+50;
							if(checkSuKien(ngaybd, ngaybd+50, type)){
								listNam.add(Integer.toString(ngaybd));

							}
						}
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listNam;
	}

	/**
	 * Kiểm tra trong năm chia nhỏ có tồn tại sự kiện hay không
	 * @param nambd
	 * @param namkt
	 * @param type
	 * @return
	 */
	public boolean checkSuKien(int nambd, int namkt, int type){
		cnn=da.getConnect();
		String sql="";
		if(type==1){
			sql="Select * from SUKIEN where YEAR(NGAYBATDAU)>="+nambd+" and YEAR(NGAYBATDAU)<"+namkt+"";
		}
		else{
			sql="Select * from NHANVAT where YEAR(NAMSINH)>="+nambd+" and YEAR(NAMSINH)<"+namkt+"";
		}
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}



	/**
	 * Lấy danh sách nhân vật hoặc sự kiện qua ajax khi click vào năm chia nhỏ
	 * @param nambd
	 * @param namkt
	 * @param type
	 * @return
	 */
	public String getListNVSK(int nambd, int namkt, int type) {
		cnn=da.getConnect();
		String kq="";
		if(type==1){
			String sql="Select * from SUKIEN where YEAR(NGAYBATDAU)>="+nambd+" and YEAR(NGAYBATDAU)<"+namkt+"";
			try {
				st=cnn.createStatement();
				rs=st.executeQuery(sql);
				while(rs.next()){
					String noiDung=rs.getString("NOIDUNG");
					String []noiDungChia=noiDung.split(" ");
					int dodai=noiDungChia.length;
					if(dodai>200)
						noiDung= ProcessString.catChuoi(noiDungChia, 0, 100);
					else
						noiDung=rs.getString("NOIDUNG");
					kq+="<div class=\"showmore\">" +
					"<div class=\"timeline-event\"><span class=\"click-sukien\">"+rs.getString("TENSUKIEN")+"</span>" +
					"<a href=\"chi-tet-nhan-vat-su-kien.html?id="+rs.getInt("MASUKIEN")+"&type=1\"><img src=\"css/next.svg\"></a></div>"
					+"<span class=\"tick tick-after\"></span>"
					+"<div class=\"timeline-detail\">"
					+"<div class=\"timeline-full-detail\">"
					+"<p>"+noiDung+"</p>"
					+"<span class=\"cd-read-more-1\">" 
					+"<a href=\"chi-tet-nhan-vat-su-kien.html?id="+rs.getInt("MASUKIEN")+"&type=1\">Đọc tiếp...</a></span>"
					+"</div>"
					+"</div>"
					+"</div>";
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{
			String sql="Select * from NHANVAT where YEAR(NAMSINH)>="+nambd+" and YEAR(NAMSINH)<"+namkt+"";
			try {
				st=cnn.createStatement();
				rs=st.executeQuery(sql);
				while(rs.next()){
					String noiDung=rs.getString("NOIDUNG");
					if(noiDung.length()>370)
						noiDung= rs.getString("NOIDUNG").substring(0, 370)+" ...";
					else
						noiDung=rs.getString("NOIDUNG");
					kq+="<div class=\"showmore\">" +
					"<div class=\"timeline-event\"><span class=\"click-sukien\">"+rs.getString("TENNHANVAT")+"</span>" +
					"<a href=\"chi-tet-nhan-vat-su-kien.html?id="+rs.getInt("MANHANVAT")+"\"><img src=\"css/next.svg\"></a></div>"
					+"<span class=\"tick tick-after\"></span>"
					+"<div class=\"timeline-detail\">"
					+"<div class=\"timeline-full-detail\">"
					+"<p>"+noiDung+"</p>"
					+"<span class=\"cd-read-more-1\">" 
					+"<a href=\"chi-tet-nhan-vat-su-kien.html?id="+rs.getInt("MANHANVAT")+"\">Đọc tiếp...</a></span>"
					+"</div>"
					+"</div>"
					+"</div>";
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return kq;
	}

	/**
	 * Lấy thông tin giai đoạn theo mã giai đoạn
	 * @param id
	 * @return
	 */
	public GiaiDoan getInfoGiaiDoan(int id) {
		cnn=da.getConnect();
		GiaiDoan giaiDoan=new GiaiDoan();
		String sql="Select * from GIAIDOAN where MAGIAIDOAN="+id+"";
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				giaiDoan.setTenGiaiDoan(rs.getString("TENGIAIDOAN"));
				giaiDoan.setNoiDung(rs.getString("NOIDUNG"));
				try{
					giaiDoan.setNgayBatDau(rs.getDate("NGAYBATDAU").toString().substring(0, 4));
				}catch (Exception e) {
					giaiDoan.setNgayBatDau("N/A");
				}
				try{
					giaiDoan.setNgayKetThuc(rs.getDate("NGAYKETTHUC").toString().substring(0, 4));
				}catch (Exception e) {
					giaiDoan.setNgayKetThuc("N/A");
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return giaiDoan;
	}

	/**
	 * Lấy thông tin nhân vật hoặc sự kiện theo id
	 * @param id
	 * @param type
	 * @return
	 */
	public NhanVatSuKien getNhanVatSuKien(int id, int type) {
		cnn=da.getConnect();
		String sql="";
		NhanVatSuKien nhanVatSuKien=new NhanVatSuKien();
		if(type==1){
			sql="Select * from SUKIEN where MASUKIEN="+id+"";
			try {
				st=cnn.createStatement();
				rs=st.executeQuery(sql);
				while(rs.next()){
					nhanVatSuKien.setTenNVSK(rs.getString("TENSUKIEN"));
					nhanVatSuKien.setNoiDung(rs.getString("NOIDUNG"));
					try{
						nhanVatSuKien.setNgayDau(rs.getDate("NGAYBATDAU").toString().substring(0, 4));
					}catch (Exception e) {
						nhanVatSuKien.setNgayDau("N/A");
					}
					try{
						nhanVatSuKien.setNgayCuoi(rs.getDate("NGAYKETTHUC").toString().substring(0, 4));
					}catch (Exception e) {
						nhanVatSuKien.setNgayCuoi("N/A");
					}
					nhanVatSuKien.setHinhAnh(rs.getString("HINHANH"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		else{
			sql="Select * from NHANVAT where MANHANVAT="+id+"";
			try {
				st=cnn.createStatement();
				rs=st.executeQuery(sql);
				while(rs.next()){
					nhanVatSuKien.setTenNVSK(rs.getString("TENNHANVAT"));
					nhanVatSuKien.setNoiDung(rs.getString("NOIDUNG"));
					try{
						nhanVatSuKien.setNgayDau(rs.getDate("NAMSINH").toString().substring(0, 4));
					}catch (Exception e) {
						nhanVatSuKien.setNgayDau("N/A");
					}
					try{
						nhanVatSuKien.setNgayCuoi(rs.getDate("NAMMAT").toString().substring(0, 4));
					}catch (Exception e) {
						nhanVatSuKien.setNgayCuoi("N/A");
					}
					nhanVatSuKien.setHinhAnh(rs.getString("HINHANH"));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return nhanVatSuKien;
	}


	/**
	 * Lấy nội dung từ csdl sau đó chia nhỏ thành các trang con mỗi trang 230 ký tự
	 * @param id
	 * @param type
	 * @return
	 */
	public ArrayList<NoiDung> getNoiDung(int id, int type) {
		cnn=da.getConnect();
		String sql="";
		ArrayList<NoiDung> noiDung =new ArrayList<NoiDung>();
		if(type==1)
			sql="Select * from SUKIEN where MASUKIEN="+id+"";
		else
			sql="Select * from NHANVAT where MANHANVAT="+id+"";
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			NoiDung nd;
			while(rs.next()){
				String baiviet =rs.getString("NOIDUNG");
				String [] baiVietChia=baiviet.split(" ");
				int dodai=baiVietChia.length;
				int sochu=230;
				int batdau =0;
				int ketthuc=230;
				int trang= dodai/sochu;
				if(trang==0){
					nd=new NoiDung();
					nd.setNoiDung(rs.getString("NOIDUNG"));
					nd.setPage("1");
					noiDung.add(nd);
				}else{
					for(int i=0;i<=trang;i++){
						nd=new NoiDung();
						if(i==trang){
							int bd=(trang)*sochu;
							nd.setNoiDung(ProcessString.catChuoi(baiVietChia,bd, dodai-1));
						}
						else
							nd.setNoiDung(ProcessString.catChuoi(baiVietChia, batdau, ketthuc));
						nd.setPage(Integer.toString(i+1));
						noiDung.add(nd);
						batdau=batdau+sochu;
						ketthuc=ketthuc+sochu;
					}
				}

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return noiDung;
	}

	/**
	 * Lấy thông tin thời kỳ theo id và load ra trang chủ
	 * @param id
	 * @return
	 */
	public ThoiKy getInfoThoiKy(int id) {
		cnn=da.getConnect();
		String sql="Select * from THOIKI where MATHOIKI="+id+"";
		ThoiKy thoiKy=new ThoiKy();
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				thoiKy.setMaThoiKy(rs.getInt("MATHOIKI"));
				thoiKy.setTenThoiKy(rs.getString("TENTHOIKI"));
				thoiKy.setNoiDung(rs.getString("NOIDUNG"));
				thoiKy.setHinhAnh(rs.getString("HINHANH"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return thoiKy;
	}





}
