package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DangNhapDAO {

	DataAccess da=new DataAccess();
	Statement st=null;
	Connection cnn=null;
	ResultSet rs=null;
	
	/**
	 * Kiểm tra đăng nhập
	 * @param userName
	 * @param password
	 * @return
	 */
	public boolean checkLogin(String userName, String password) {
		cnn=da.getConnect();
		String sql="select * from ACCOUNT where USERNAME='"+userName+"' and pass='"+password+"'";
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	public static void main(String[] args) {
		DangNhapDAO dangNhapDAO =new DangNhapDAO();
		System.out.println(dangNhapDAO.checkLogin("admin", "123"));
	}

}
