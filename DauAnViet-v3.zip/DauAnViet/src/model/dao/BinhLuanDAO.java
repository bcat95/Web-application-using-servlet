package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.been.BinhLuan;

public class BinhLuanDAO {

	DataAccess da=new DataAccess();
	Statement st=null;
	Connection cnn=null;
	ResultSet rs=null;
	
	/**
	 * Lấy bình luận từ csdl theo id bài viết và kiểu bài viết
	 * @param id
	 * @param type
	 * @return arraylist
	 */
	public ArrayList<BinhLuan> getBinhLuan(int id, int type) {
		cnn=da.getConnect();
		String sql="";
		if(type==1)
			sql="Select top 10 MABINHLUAN, TEN, NOIDUNG, NGAYBINHLUAN, BINHLUAN.USERNAME, HINHDAIDIEN from BINHLUAN inner join ACCOUNT on BINHLUAN.USERNAME = ACCOUNT.USERNAME where MASUKIEN="+id+" and PHEDUYET="+1+" ORDER BY MABINHLUAN DESC;";
		else
			sql="Select top 10 MABINHLUAN, TEN, NOIDUNG, NGAYBINHLUAN, BINHLUAN.USERNAME, HINHDAIDIEN from BINHLUAN inner join ACCOUNT on BINHLUAN.USERNAME = ACCOUNT.USERNAME where MANHANVAT="+id+" and PHEDUYET="+1+" ORDER BY MABINHLUAN DESC;";

		ArrayList<BinhLuan> binhLuan =new ArrayList<BinhLuan>();
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			BinhLuan bl;
			while(rs.next()){
				bl=new BinhLuan();
				bl.setMaBinhLuan(rs.getInt("MABINHLUAN"));
				bl.setNoiDung(rs.getString("NOIDUNG"));
				bl.setNgayDang(rs.getString("NGAYBINHLUAN"));
				bl.setHinhDaiDien(rs.getString("HINHDAIDIEN"));
				bl.setUserName(rs.getString("TEN"));
				binhLuan.add(bl);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}

		return binhLuan;
	}

	/**
	 * Thêm bình luận vào csdl
	 * @param id
	 * @param type
	 * @param userName
	 * @param ngayDang
	 * @param noiDung
	 * @param typeUser 
	 */
	public void addBinhLuan(int id, int type, String userName, String ngayDang,
			String noiDung, int typeUser) {

		cnn=da.getConnect();
		String sql="";
		if(type==1)
			if(typeUser==1)
				sql="insert into BINHLUAN(NOIDUNG, NGAYBINHLUAN, USERNAME, MASUKIEN, PHEDUYET) values (N'"+noiDung+"', '"+ngayDang+"', '"+userName+"', "+id+","+1+")";
			else
				sql="insert into BINHLUAN(NOIDUNG, NGAYBINHLUAN, USERNAME, MASUKIEN) values (N'"+noiDung+"', '"+ngayDang+"', '"+userName+"', "+id+")";
		else
			if(typeUser==1)
				sql="insert into BINHLUAN(NOIDUNG, NGAYBINHLUAN, USERNAME, MANHANVAT, PHEDUYET) values (N'"+noiDung+"', '"+ngayDang+"', '"+userName+"', "+id+","+1+")";
			else
				sql="insert into BINHLUAN(NOIDUNG, NGAYBINHLUAN, USERNAME, MANHANVAT) values (N'"+noiDung+"', '"+ngayDang+"', '"+userName+"', "+id+")";
		try {
			st=cnn.createStatement();
			st.executeUpdate(sql);	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


	/**
	 * Đếm số bình luận theo id và kiểu bài viết
	 * @param id
	 * @param type
	 * @return
	 */
	public int countBinhLuan(int id, int type) {
		cnn=da.getConnect();
		String sql="";
		int soLuong=0;
		if(type==1)
			sql="Select count(*) as soluong from BINHLUAN where MASUKIEN="+id+" and PHEDUYET="+1+"";
		else
			sql="Select count(*) as soluong from BINHLUAN where MANHANVAT="+id+" and PHEDUYET="+1+"";
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				soLuong=rs.getInt("soluong");
			}
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return soLuong;
	}

	/**
	 * Lấy bình luận bằng ajax khi click vào xem thêm
	 * @param id
	 * @param type
	 * @param numComment
	 * @return
	 */
	public String getBinhLuanAjax(int id, int type, int numComment) {
		cnn=da.getConnect();
		String sql="";
		String kq="";
		if(type==1)
			sql="Select top "+numComment+" MABINHLUAN, TEN, NOIDUNG, NGAYBINHLUAN, BINHLUAN.USERNAME, HINHDAIDIEN from BINHLUAN inner join ACCOUNT on BINHLUAN.USERNAME = ACCOUNT.USERNAME where MASUKIEN="+id+" and PHEDUYET="+1+" ORDER BY MABINHLUAN DESC;";
		else
			sql="Select top "+numComment+" MABINHLUAN, TEN, NOIDUNG, NGAYBINHLUAN, BINHLUAN.USERNAME, HINHDAIDIEN from BINHLUAN inner join ACCOUNT on BINHLUAN.USERNAME = ACCOUNT.USERNAME where MANHANVAT="+id+" and PHEDUYET="+1+" ORDER BY MABINHLUAN DESC;";

	
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);

			while(rs.next()){
				kq+="<li>" +
				"<img src=\""+rs.getString("HINHDAIDIEN")+"\" class=\"cmt-img\">" +
				"<span class=\"cmt-time\">"+rs.getString("NGAYBINHLUAN")+"</span>" +
				"<div class=\"cmt-name\" title=\""+rs.getString("TEN")+"\">"+rs.getString("TEN")+"</div>" +
				"<div class=\"cmt-content\">"+rs.getString("NOIDUNG")+"</div>" +
				"</li>";
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return kq;
	}
	
	public static void main(String[] args) {
		BinhLuanDAO binhLuanDAO=new BinhLuanDAO();
		binhLuanDAO.getBinhLuanAjax(8, 2,15);
	}

	public int checkTypeUser(String userName) {
		cnn=da.getConnect();
		String sql="select PHANQUYEN from ACCOUNT where userName='"+userName+"'";
		int type=0;
		try {
			st=cnn.createStatement();
			rs=st.executeQuery(sql);
			while(rs.next()){
				 type=rs.getInt("PHANQUYEN");
			
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return type;
		
	}

	
}
