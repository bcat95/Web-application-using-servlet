package model.been;


public class SuKien {

	private int maSuKien;
	private String tenSuKien;
	private String ngayBatDau;
	private String ngayKetThuc;
	private String noiDung;
	private String hinhAnh;
	private String maGiaiDoan;
	private String maPhanLoai;
	public int getMaSuKien() {
		return maSuKien;
	}
	public void setMaSuKien(int maSuKien) {
		this.maSuKien = maSuKien;
	}
	public String getTenSuKien() {
		return tenSuKien;
	}
	public void setTenSuKien(String tenSuKien) {
		this.tenSuKien = tenSuKien;
	}
	public String getNgayBatDau() {
		return ngayBatDau;
	}
	public void setNgayBatDau(String ngayBatDau) {
		this.ngayBatDau = ngayBatDau;
	}
	public String getNgayKetThuc() {
		return ngayKetThuc;
	}
	public void setNgayKetThuc(String ngayKetThuc) {
		this.ngayKetThuc = ngayKetThuc;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public String getHinhAnh() {
		return hinhAnh;
	}
	public void setHinhAnh(String hinhAnh) {
		this.hinhAnh = hinhAnh;
	}
	public String getMaGiaiDoan() {
		return maGiaiDoan;
	}
	public void setMaGiaiDoan(String maGiaiDoan) {
		this.maGiaiDoan = maGiaiDoan;
	}
	public String getMaPhanLoai() {
		return maPhanLoai;
	}
	public void setMaPhanLoai(String maPhanLoai) {
		this.maPhanLoai = maPhanLoai;
	}
	
	
}
