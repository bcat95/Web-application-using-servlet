package model.been;

public class BinhLuan {

	private int maBinhLuan;
	private String noiDung;
	private String ngayDang;
	private String userName;
	private String hinhDaiDien;
	
	public int getMaBinhLuan() {
		return maBinhLuan;
	}
	public void setMaBinhLuan(int maBinhLuan) {
		this.maBinhLuan = maBinhLuan;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public String getNgayDang() {
		return ngayDang;
	}
	public void setNgayDang(String ngayDang) {
		this.ngayDang = ngayDang;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getHinhDaiDien() {
		return hinhDaiDien;
	}
	public void setHinhDaiDien(String hinhDaiDien) {
		this.hinhDaiDien = hinhDaiDien;
	}
	
	
	
	
}
