package model.been;


public class GiaiDoan {
	private int maGiaiDoan;
	private int maThoiKy;
	private String tenGiaiDoan;
	private String ngayBatDau;
	private String ngayKetThuc;
	private String noiDung;
	private String banDoGiaiDoan;
	private String hinhAnh;
	
	
	public int getMaGiaiDoan() {
		return maGiaiDoan;
	}
	public void setMaGiaiDoan(int maGiaiDoan) {
		this.maGiaiDoan = maGiaiDoan;
	}
	public int getMaThoiKy() {
		return maThoiKy;
	}
	public void setMaThoiKy(int maThoiKy) {
		this.maThoiKy = maThoiKy;
	}
	public String getTenGiaiDoan() {
		return tenGiaiDoan;
	}
	public void setTenGiaiDoan(String tenGiaiDoan) {
		this.tenGiaiDoan = tenGiaiDoan;
	}
	public String getNgayBatDau() {
		return ngayBatDau;
	}
	public void setNgayBatDau(String ngayBatDau) {
		this.ngayBatDau = ngayBatDau;
	}
	public String getNgayKetThuc() {
		return ngayKetThuc;
	}
	public void setNgayKetThuc(String ngayKetThuc) {
		this.ngayKetThuc = ngayKetThuc;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public String getBanDoGiaiDoan() {
		return banDoGiaiDoan;
	}
	public void setBanDoGiaiDoan(String banDoGiaiDoan) {
		this.banDoGiaiDoan = banDoGiaiDoan;
	}
	public String getHinhAnh() {
		return hinhAnh;
	}
	public void setHinhAnh(String hinhAnh) {
		this.hinhAnh = hinhAnh;
	}
	
	
	
}
