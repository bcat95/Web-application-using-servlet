package model.been;

public class NhanVatSuKien {
	private String tenNVSK;
	private String noiDung;
	private String ngayDau;
	private String ngayCuoi;
	private String hinhAnh;
	
	public String getTenNVSK() {
		return tenNVSK;
	}
	public void setTenNVSK(String tenNVSK) {
		this.tenNVSK = tenNVSK;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public String getNgayDau() {
		return ngayDau;
	}
	public void setNgayDau(String ngayDau) {
		this.ngayDau = ngayDau;
	}
	public String getNgayCuoi() {
		return ngayCuoi;
	}
	public void setNgayCuoi(String ngayCuoi) {
		this.ngayCuoi = ngayCuoi;
	}
	public String getHinhAnh() {
		return hinhAnh;
	}
	public void setHinhAnh(String hinhAnh) {
		this.hinhAnh = hinhAnh;
	}
	
	

}
