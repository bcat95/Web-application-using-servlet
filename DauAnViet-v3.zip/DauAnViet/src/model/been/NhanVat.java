package model.been;

public class NhanVat {

	private int maNhanVat;
	private String tenNhanVat;
	private String namSinh;
	private String namMat;
	private String noiDung;
	private String hinhAnh;
	
	
	public int getMaNhanVat() {
		return maNhanVat;
	}
	public void setMaNhanVat(int maNhanVat) {
		this.maNhanVat = maNhanVat;
	}
	public String getTenNhanVat() {
		return tenNhanVat;
	}
	public void setTenNhanVat(String tenNhanVat) {
		this.tenNhanVat = tenNhanVat;
	}
	public String getNamSinh() {
		return namSinh;
	}
	public void setNamSinh(String namSinh) {
		this.namSinh = namSinh;
	}
	public String getNamMat() {
		return namMat;
	}
	public void setNamMat(String namMat) {
		this.namMat = namMat;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public String getHinhAnh() {
		return hinhAnh;
	}
	public void setHinhAnh(String hinhAnh) {
		this.hinhAnh = hinhAnh;
	}

	
}
