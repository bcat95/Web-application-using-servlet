package model.been;

public class ThoiKy {

	private int maThoiKy;
	private String tenThoiKy;
	private String noiDung;
	private String hinhAnh;
	private String thoiGian;
	
	public int getMaThoiKy() {
		return maThoiKy;
	}
	public void setMaThoiKy(int maThoiKy) {
		this.maThoiKy = maThoiKy;
	}
	public String getTenThoiKy() {
		return tenThoiKy;
	}
	public void setTenThoiKy(String tenThoiKy) {
		this.tenThoiKy = tenThoiKy;
	}
	public String getNoiDung() {
		return noiDung;
	}
	public void setNoiDung(String noiDung) {
		this.noiDung = noiDung;
	}
	public String getHinhAnh() {
		return hinhAnh;
	}
	public void setHinhAnh(String hinhAnh) {
		this.hinhAnh = hinhAnh;
	}
	public String getThoiGian() {
		return thoiGian;
	}
	public void setThoiGian(String thoiGian) {
		this.thoiGian = thoiGian;
	}
	
	
}
