package model.bo;

import java.util.ArrayList;

import model.been.SuKien;
import model.dao.SuKienDAO;

public class SuKienBO {

	SuKienDAO suKienDAO =new SuKienDAO();
	
	/**
	 * Lấy top sự kiện
	 * @return
	 */
	public ArrayList<SuKien> getTopSuKien() {
		return suKienDAO.getTopSuKien();
	}
	/**
	 * Lấy top sự kiện sắp diễn ra
	 * @param ngayDang
	 * @param ngay
	 * @param thang
	 * @return
	 */
	public ArrayList<SuKien> getTopSuKienSDR(String ngayDang, int ngay, int thang) {
		return suKienDAO.getTopSuKienSDR(ngayDang ,ngay,thang);
	}
	
	/**
	 * Lấy top sự kiện mới cập nhật
	 * @return
	 */
	public ArrayList<SuKien> getTopSuKienMoi() {
		// TODO Auto-generated method stub
		return suKienDAO.getTopSuKienMoi();
	}

}
