package model.bo;

import java.util.ArrayList;

import model.been.GiaiDoan;
import model.been.NhanVatSuKien;
import model.been.NoiDung;
import model.been.ThoiKy;
import model.dao.GiaiDoanDAO;

public class GiaiDoanBO {

	GiaiDoanDAO giaiDoanDAO = new GiaiDoanDAO();
	
	/**
	 * Lấy danh sách giai đoạn theo mã thời kỳ
	 * @param id
	 * @return
	 */
	public ArrayList<GiaiDoan> getListGiaiDoan(int id) {
		return giaiDoanDAO.getListGiaiDoan(id);
	}
	
	/**
	 * Lấy số lượng giai đoạn có trong thời kỳ
	 * @param id
	 * @return
	 */
	public ArrayList<String> getPageGiaiDoan(int id) {
		return giaiDoanDAO.getPageGiaiDoan(id);
	}
	
	/**
	 * Lấy năm chia nhỏ trong giai đoạn
	 * @param id
	 * @param type
	 * @return
	 */
	public ArrayList<String> getNamChiaNho(int id, int type) {
		return giaiDoanDAO.getNamChiaNho(id, type);
	}
	
	/**
	 * Lấy danh sách nhân vật hoặc sự kiện
	 * @param nambd
	 * @param namkt
	 * @param type
	 * @return
	 */
	public String getListNVSK(int nambd, int namkt, int type) {
		
		return giaiDoanDAO.getListNVSK(nambd, namkt, type);
	}
	
	/**
	 * Lấy thông tin giai đoạn
	 * @param id
	 * @return
	 */
	public GiaiDoan getInfoGiaiDoan(int id) {
		return giaiDoanDAO.getInfoGiaiDoan(id);
	}
	
	/**
	 * Lấy thông tin nhân vật hoặc sự kiện
	 * @param id
	 * @param type
	 * @return
	 */
	public NhanVatSuKien getNhanVatSuKien(int id, int type) {
		return giaiDoanDAO.getNhanVatSuKien(id, type);
	}
	
	/**
	 * Lấy nội dung nhân vật hoặc sự kiện
	 * @param id
	 * @param type
	 * @return
	 */
	public ArrayList<NoiDung> getNoiDung(int id, int type) {
		return giaiDoanDAO.getNoiDung(id, type);
	}
	
	/**
	 * Lấy thông tin thời kỳ
	 * @param id
	 * @return
	 */
	public ThoiKy getInfoThoiKy(int id) {
		return giaiDoanDAO.getInfoThoiKy(id);
	}

}
