package model.bo;

import java.util.ArrayList;

import model.been.NhanVat;
import model.dao.NhanVatDAO;

public class NhanVatBO {

	NhanVatDAO nhanVatDAO =new NhanVatDAO();
	
	/**
	 * Lấy top nhân vật được xem nhiều nhất
	 * @return
	 */
	public ArrayList<NhanVat> getTopNhanVat() {
		return nhanVatDAO.getTopNhanVat();
	}

	/**
	 * Lấy danh sách nhân vật mới cập nhật
	 * @return
	 */
	public ArrayList<NhanVat> getNhanVatMoi() {
		return nhanVatDAO.getNhanVatMoi();
	}

}
