package form;

import org.apache.struts.action.ActionForm;

public class HeaderForm extends ActionForm{

	private String dangNhap;
	private String dangKy;
	
	public String getDangNhap() {
		return dangNhap;
	}
	public void setDangNhap(String dangNhap) {
		this.dangNhap = dangNhap;
	}
	public String getDangKy() {
		return dangKy;
	}
	public void setDangKy(String dangKy) {
		this.dangKy = dangKy;
	}
	
	
}
