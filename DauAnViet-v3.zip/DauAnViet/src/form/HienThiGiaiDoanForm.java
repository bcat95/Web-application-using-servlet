package form;

import java.util.ArrayList;

import model.been.GiaiDoan;
import model.been.ThoiKy;

import org.apache.struts.action.ActionForm;

public class HienThiGiaiDoanForm extends ActionForm{
	private int id;
	private ArrayList<GiaiDoan> listGiaiDoan;
	private ArrayList<String> giaiDoan;
	private ThoiKy thoiKy;
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public ArrayList<GiaiDoan> getListGiaiDoan() {
		return listGiaiDoan;
	}

	public void setListGiaiDoan(ArrayList<GiaiDoan> listGiaiDoan) {
		this.listGiaiDoan = listGiaiDoan;
	}

	public ArrayList<String> getGiaiDoan() {
		return giaiDoan;
	}

	public void setGiaiDoan(ArrayList<String> giaiDoan) {
		this.giaiDoan = giaiDoan;
	}

	public ThoiKy getThoiKy() {
		return thoiKy;
	}

	public void setThoiKy(ThoiKy thoiKy) {
		this.thoiKy = thoiKy;
	}

	

	
}
