package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.been.BinhLuan;
import model.been.NhanVatSuKien;
import model.been.NoiDung;
import model.bo.BinhLuanBO;
import model.bo.GiaiDoanBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.ChiTietNhanVatSuKienForm;

public class ChiTietNhanVatSuKienAction extends Action{
	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ChiTietNhanVatSuKienForm chiTietNhanVatSuKienForm = (ChiTietNhanVatSuKienForm) form;
		
		int id= chiTietNhanVatSuKienForm.getId();
		int type= chiTietNhanVatSuKienForm.getType();
		GiaiDoanBO giaiDoanBO=new GiaiDoanBO();
		NhanVatSuKien nhanVatSuKien= giaiDoanBO.getNhanVatSuKien(id, type);
		chiTietNhanVatSuKienForm.setNhanVatSuKien(nhanVatSuKien);
		ArrayList<NoiDung> arrayList= giaiDoanBO.getNoiDung(id, type);
		chiTietNhanVatSuKienForm.setNoiDung(arrayList);
		
		BinhLuanBO binhLuanBO =new BinhLuanBO();
		ArrayList<BinhLuan> binhLuan= binhLuanBO.getBinhLuan(id, type);
		chiTietNhanVatSuKienForm.setBinhLuan(binhLuan);
		int soBinhLuan= binhLuanBO.countBinhLuan(id,type);
		if(soBinhLuan>10){
		chiTietNhanVatSuKienForm.setXemThem("Xem thêm");
		}else
			chiTietNhanVatSuKienForm.setXemThem("");
		return mapping.findForward("success");
	}

}
