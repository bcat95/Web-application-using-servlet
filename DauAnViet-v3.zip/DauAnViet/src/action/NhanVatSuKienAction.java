package action;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.been.GiaiDoan;
import model.bo.GiaiDoanBO;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import form.NhanVatSuKienForm;

public class NhanVatSuKienAction extends Action{

	@Override
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		NhanVatSuKienForm nhanVatSuKienForm = (NhanVatSuKienForm) form;
		int id = nhanVatSuKienForm.getId();
		int type=nhanVatSuKienForm.getType();
		if(type==1)
			nhanVatSuKienForm.setTypeName("Sự Kiện");
		
		else
			nhanVatSuKienForm.setTypeName("Nhân Vật");
		GiaiDoanBO giaiDoanBO = new GiaiDoanBO();
		ArrayList<String> namChiaNho = giaiDoanBO.getNamChiaNho(id, type);
		nhanVatSuKienForm.setNamChiaNho(namChiaNho);
		GiaiDoan giaiDoan = giaiDoanBO.getInfoGiaiDoan(id);
		nhanVatSuKienForm.setGiaiDoan(giaiDoan);
		return mapping.findForward("success");
	}
}
