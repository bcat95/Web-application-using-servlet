package model.bo;

import java.sql.Date;

import model.dao.TruyCapDAO;

public class TruyCapBO {
	TruyCapDAO capDAO = new TruyCapDAO();
}
