package model.bo;

import java.sql.Date;

import model.dao.TroGiupDAO;

public class TroGiupBO {
	
TroGiupDAO giupDAO = new TroGiupDAO();
}
