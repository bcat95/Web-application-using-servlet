package model.bo;

import model.dao.LoaiTinDAO;

public class LoaiTinBO {
	LoaiTinDAO loaiTinDAO = new LoaiTinDAO();
}
