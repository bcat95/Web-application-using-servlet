package model.dao;

public class LoaiTinDAO {
	
}
