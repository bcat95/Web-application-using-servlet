package model.dao;

import java.sql.Date;

public class TroGiupDAO {
	

}
